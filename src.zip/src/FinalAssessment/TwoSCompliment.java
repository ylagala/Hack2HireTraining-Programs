package FinalAssessment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class TwoSCompliment {

	public static void main(String[] args) {
		   Scanner sc = new Scanner(System.in);
	        int n = sc.nextInt(),a,b,count;
	        for(int j=0;j<n;j++) {
	            a = sc.nextInt();
	            b = sc.nextInt();
	            count=0;
	            for(int i=a;i<=b;i++) {
	                String s = Integer.toBinaryString(i);
	                int length = s.length();
	                String[] c =  s.split("");
	                for(int k=0; k<c.length; k++){
	                if(Integer.parseInt(c[k]) == 1){
	                	count++;
	                }
	                }
	                //List<String> list = new ArrayList<String>(Arrays.asList(s.split("")));
	                //count+=Collections.frequency(list, "1");
	            }
	            System.out.println(count);
	        }

	}

}
