package FinalAssessment;

import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.LongStream;
import java.util.stream.Stream;

public class ArrayManipulation {

	   public static void main(String[] args) {
	        Scanner in = new Scanner(System.in);
	        int n = in.nextInt();
	        int m = in.nextInt();
	        int[] res = new int[n];
	        for(int a0 = 0; a0 < m; a0++){
	            int a = in.nextInt();
	            int b = in.nextInt();
	            int k = in.nextInt();
	            for(int j=a-1; j<b; j++){
				     res[j] += k;
				 }	
	        }
	       
	        System.out.println(Arrays.stream(res).max().getAsInt());
	        in.close();
	    }
}
