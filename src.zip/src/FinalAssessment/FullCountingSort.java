package FinalAssessment;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class FullCountingSort {

	public static void main(String[] args) {
		 Scanner in = new Scanner(System.in);
	        List<String> list = new ArrayList<>();
	        int n = in.nextInt();
	        int n2 = n/2;
	        for(int i=0; i<n2; i++){
	            list.add(in.nextInt() + " -");
	            in.next();
	        }
	        for(int i=n2; i<n; i++){
	            list.add(in.nextInt()+" "+in.next());
	        }
	        list.sort(new Comparator<String>() {
	        	@Override
	        	public int compare(String o1, String o2) {
	        		return Integer.parseInt(o1.substring(0,2).trim()) - Integer.parseInt(o2.substring(0,2).trim());
	        	}
			});
	        System.out.println(list);
	        in.close();

	}

}
