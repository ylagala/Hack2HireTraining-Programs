package FinalAssessment;

import java.util.Scanner;

public class ANDxorOR {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        long[] arr = new long[n];
        long max = 0, temp=0;
       for(int i=0; i<n; i++){
           arr[i] = in.nextInt();
       }
        //System.out.print(Arrays.toString(arr));
        for(int i=0; i<n-1; i++){
            temp = (((arr[i] & arr[i+1])^(arr[i] | arr[i+1]))&(arr[i] ^ arr[i+1])) ;
                if(max < temp){
                    max = temp;
                }
        }
        System.out.println("hi");
        System.out.println(max);
        in.close();

	}

}
