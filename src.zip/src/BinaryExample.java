
public class BinaryExample {

	public static void main(String[] args) {
     int i = 4;
     System.out.println(Integer.toBinaryString(i)+Integer.toBinaryString(5));
      
     System.out.println(Integer.valueOf("100", 2));
     System.out.println(4<<1);
    

	}

}
